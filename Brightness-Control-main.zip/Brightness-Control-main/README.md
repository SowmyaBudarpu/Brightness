# Brightness-Control
Brightness Control With Hand Detection using OpenCV in Python.
